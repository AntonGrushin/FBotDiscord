-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 16, 2018 at 03:02 PM
-- Server version: 5.5.55-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ghost`
--

-- --------------------------------------------------------

--
-- Table structure for table `chatlog`
--

CREATE TABLE `chatlog` (
  `id` int(11) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `gameticks` int(10) UNSIGNED NOT NULL,
  `gameid` int(11) NOT NULL,
  `gamestatus` tinyint(4) NOT NULL COMMENT '0 lobby, 1 loading, 2 started, 3 finished',
  `gameFinished` tinyint(4) NOT NULL DEFAULT '0',
  `player` int(10) UNSIGNED NOT NULL,
  `name` varchar(32) CHARACTER SET latin1 NOT NULL,
  `server` varchar(100) CHARACTER SET latin1 NOT NULL,
  `target` varchar(100) CHARACTER SET latin1 NOT NULL,
  `message` varchar(1024) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `discord`
--

CREATE TABLE `discord` (
  `id` int(10) UNSIGNED NOT NULL,
  `gametrack_id` int(10) UNSIGNED NOT NULL,
  `wc3_name` varchar(30) NOT NULL,
  `wc3_server` varchar(40) NOT NULL,
  `register_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `discord_userid` bigint(20) UNSIGNED NOT NULL,
  `discord_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Stand-in structure for view `discord_view`
-- (See below for the actual view)
--
CREATE TABLE `discord_view` (
`id` int(10) unsigned
,`gametrack_id` int(10) unsigned
,`wc3_name` varchar(30)
,`wc3_server` varchar(40)
,`register_date` timestamp
,`discord_userid` bigint(20) unsigned
,`discord_name` varchar(100)
,`rank` int(11)
,`rank_historyMax` int(10) unsigned
);

-- --------------------------------------------------------

--
-- Table structure for table `gametrack`
--

CREATE TABLE `gametrack` (
  `id` int(11) NOT NULL,
  `name` varchar(15) DEFAULT NULL,
  `realm` varchar(100) DEFAULT NULL,
  `bots` varchar(40) DEFAULT NULL,
  `lastgames` varchar(500) DEFAULT NULL,
  `total_leftpercent` double DEFAULT NULL,
  `num_leftpercent` int(11) DEFAULT NULL,
  `num_games` int(11) DEFAULT NULL,
  `time_created` timestamp NULL DEFAULT NULL,
  `time_active` timestamp NULL DEFAULT NULL,
  `playingtime` int(11) DEFAULT NULL,
  `playingtime_Elo` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `desiredCountryCode` varchar(2) NOT NULL,
  `lastCountryCode` varchar(2) NOT NULL,
  `pvillager` int(11) DEFAULT '0',
  `pwolf` int(11) DEFAULT '0',
  `wvillager` int(11) DEFAULT '0',
  `wwolf` int(11) DEFAULT '0',
  `rank` int(11) DEFAULT '0',
  `ppoints` int(11) DEFAULT NULL,
  `elo_rating` double NOT NULL DEFAULT '1500',
  `elo_historyMax` float NOT NULL DEFAULT '1500',
  `elo_historyMin` float NOT NULL DEFAULT '1500',
  `eloMax_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `eloMin_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `rank_historyMax` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `rankMax_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `password` char(5) NOT NULL DEFAULT 'uE6dZ',
  `discordRegistered` tinyint(1) NOT NULL DEFAULT '0',
  `wantToBeWW` tinyint(4) NOT NULL DEFAULT '0' COMMENT '-1 no, 0 dont_care, 1 yes',
  `ww_experice` double NOT NULL DEFAULT '0',
  `toxic` float UNSIGNED NOT NULL DEFAULT '0' COMMENT 'How toxic the player is (teamkilling)',
  `wSlain` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `vSlain` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `VTotal` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Total amount of Villagers played against this player as WW',
  `TKs` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `TKVTotal` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Total amount of Villagers played with this player as villager',
  `totalGold` int(10) UNSIGNED NOT NULL,
  `totalWood` int(10) UNSIGNED NOT NULL,
  `lastGameWasWW` tinyint(3) UNSIGNED NOT NULL COMMENT 'how many games in a row this player was werewolf',
  `diedToAnimals` int(10) UNSIGNED NOT NULL,
  `totalGamesEloCount` int(10) UNSIGNED NOT NULL,
  `playedAsWerewolf` int(10) UNSIGNED NOT NULL COMMENT 'seconds',
  `playedAsVillager` int(10) UNSIGNED NOT NULL COMMENT 'seconds',
  `playedAsZombie` int(10) UNSIGNED NOT NULL COMMENT 'seconds'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `wwt_current_games`
--

CREATE TABLE `wwt_current_games` (
  `id` int(10) UNSIGNED NOT NULL,
  `botid` int(10) UNSIGNED NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '0 - lobby, 1 - loading, 2 started',
  `date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `gamename` varchar(100) NOT NULL,
  `lobby_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `game_startedloading` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `game_started` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `duration` int(10) UNSIGNED NOT NULL,
  `isNight` tinyint(4) NOT NULL DEFAULT '0',
  `day` smallint(5) UNSIGNED NOT NULL,
  `night` smallint(5) UNSIGNED NOT NULL,
  `werewolf_repicks` tinyint(3) UNSIGNED NOT NULL,
  `HCL_order` int(10) UNSIGNED NOT NULL,
  `Elo_importance` int(11) NOT NULL DEFAULT '0',
  `no_secrets` tinyint(3) UNSIGNED NOT NULL COMMENT '0 usual, 1 no_secrets',
  `noZombies` tinyint(3) UNSIGNED NOT NULL,
  `swapNames` tinyint(3) UNSIGNED NOT NULL,
  `timesRepubbed` int(10) UNSIGNED NOT NULL,
  `startplayers` tinyint(3) UNSIGNED NOT NULL,
  `players` tinyint(3) UNSIGNED NOT NULL,
  `villagers` tinyint(3) UNSIGNED NOT NULL,
  `zombies` tinyint(3) UNSIGNED NOT NULL,
  `wwBoost` int(10) UNSIGNED NOT NULL,
  `players_list` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure for view `discord_view`
--
DROP TABLE IF EXISTS `discord_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `discord_view`  AS  select `discord`.`id` AS `id`,`discord`.`gametrack_id` AS `gametrack_id`,`discord`.`wc3_name` AS `wc3_name`,`discord`.`wc3_server` AS `wc3_server`,`discord`.`register_date` AS `register_date`,`discord`.`discord_userid` AS `discord_userid`,`discord`.`discord_name` AS `discord_name`,`gametrack`.`rank` AS `rank`,`gametrack`.`rank_historyMax` AS `rank_historyMax` from (`discord` join `gametrack`) where (`discord`.`gametrack_id` = `gametrack`.`id`) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chatlog`
--
ALTER TABLE `chatlog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `discord`
--
ALTER TABLE `discord`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gametrack`
--
ALTER TABLE `gametrack`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `realm` (`realm`);

--
-- Indexes for table `wwt_current_games`
--
ALTER TABLE `wwt_current_games`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chatlog`
--
ALTER TABLE `chatlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=543249;

--
-- AUTO_INCREMENT for table `discord`
--
ALTER TABLE `discord`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `gametrack`
--
ALTER TABLE `gametrack`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20955;

--
-- AUTO_INCREMENT for table `wwt_current_games`
--
ALTER TABLE `wwt_current_games`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=325;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
