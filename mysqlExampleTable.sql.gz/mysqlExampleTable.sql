-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 14, 2018 at 08:56 PM
-- Server version: 5.5.55-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ghost`
--

-- --------------------------------------------------------

--
-- Table structure for table `chatlog`
--

CREATE TABLE `chatlog` (
  `id` int(11) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `gameticks` int(10) UNSIGNED NOT NULL,
  `gameid` int(11) NOT NULL,
  `gamestatus` tinyint(4) NOT NULL COMMENT '0 lobby, 1 loading, 2 started, 3 finished',
  `gameFinished` tinyint(4) NOT NULL DEFAULT '0',
  `player` int(10) UNSIGNED NOT NULL,
  `name` varchar(32) CHARACTER SET latin1 NOT NULL,
  `server` varchar(100) CHARACTER SET latin1 NOT NULL,
  `target` varchar(100) CHARACTER SET latin1 NOT NULL,
  `message` varchar(1024) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `wwt_current_games`
--

CREATE TABLE `wwt_current_games` (
  `id` int(10) UNSIGNED NOT NULL,
  `botid` int(10) UNSIGNED NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '0 - lobby, 1 - loading, 2 started',
  `date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `gamename` varchar(100) NOT NULL,
  `lobby_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `game_startedloading` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `game_started` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `duration` int(10) UNSIGNED NOT NULL,
  `isNight` tinyint(4) NOT NULL DEFAULT '0',
  `day` smallint(5) UNSIGNED NOT NULL,
  `night` smallint(5) UNSIGNED NOT NULL,
  `werewolf_repicks` tinyint(3) UNSIGNED NOT NULL,
  `HCL_order` int(10) UNSIGNED NOT NULL,
  `Elo_importance` int(11) NOT NULL DEFAULT '0',
  `no_secrets` tinyint(3) UNSIGNED NOT NULL COMMENT '0 usual, 1 no_secrets',
  `noZombies` tinyint(3) UNSIGNED NOT NULL,
  `swapNames` tinyint(3) UNSIGNED NOT NULL,
  `timesRepubbed` int(10) UNSIGNED NOT NULL,
  `startplayers` tinyint(3) UNSIGNED NOT NULL,
  `players` tinyint(3) UNSIGNED NOT NULL,
  `villagers` tinyint(3) UNSIGNED NOT NULL,
  `zombies` tinyint(3) UNSIGNED NOT NULL,
  `wwBoost` int(10) UNSIGNED NOT NULL,
  `players_list` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wwt_current_games`
--

INSERT INTO `wwt_current_games` (`id`, `botid`, `status`, `date`, `gamename`, `lobby_created`, `game_startedloading`, `game_started`, `duration`, `isNight`, `day`, `night`, `werewolf_repicks`, `HCL_order`, `Elo_importance`, `no_secrets`, `noZombies`, `swapNames`, `timesRepubbed`, `startplayers`, `players`, `villagers`, `zombies`, `wwBoost`, `players_list`) VALUES
(254, 0, 2, '2018-03-14 17:56:03', 'Werewolf Transylvania #325', '2018-03-14 19:34:38', '2018-03-14 19:47:43', '2018-03-14 19:48:06', 4027600, 0, 9, 8, 1, 0, 0, 0, 0, 1, 4, 0, 3, 1, 2, 0, '1	DaNewbzPWN	0	109.41.193.244	ip-109-41-193-244.web.vodafone.de	DE	europe.battle.net		0	0	blue	5	0	0	0	184303	0.00	0	82	67	55	12	20	1	377	377	1378.0792	0.00	0.00	5	9	46	0	333	0	27035	535	3569	64	433502	433200	649864	0	351982	279784	6	0	442228	207575	261727	712975	0	0	0	0	2427725	0	0	0	20	0	0	0	0	0	0	263882790666240	12	0	0	1619	9	2	1	Derpino	3	83.26.255.57	atr57.neoplus.adsl.tpnet.pl	PL	europe.battle.net		0	0	Unlucky Name	0	0	0	0	260782	0.00	0	97	101	74	22	45	18	38	48	1554.1573	0.00	0.00	11	82	88	1	379	6206	100621	210	97392	40864	171362	0	30427	0	6892	1507	412	0	628	353	0	0	5628	204	55729508	60873684	19719625	0	0	0	6579	0	0	0	0	0	0	281471155668864	25	0	0	0	100	0	1	Velops	10	24.178.228.95	24-178-228-95.dhcp.stls.mo.charter.com	US	useast.battle.net		0	0	Rat On a Hat	0	0	0	0	69860	0.00	0	94	23	16	7	3	2	70	70	1509.0323	0.00	0.00	0	15	27	0	91	6353	40171	3020	33253	14017	25055	24430	96044	14340	0	14099	0	0	3163	978	3692	0	0	3730	28200	26988	3730	0	0	0	0	0	0	0	0	0	0	281471193417712	25	0	0	3089	9	2	0	Tertlu	6	212.53.104.117	m212-53-104-117.cust.tele2.ee	EE	europe.battle.net		0	0	Fish Oil	0	0	0	0	5612	0.00	1064	56.00	2	2	0	0	0	3509	3509	1496.7168	0.00	0.00	0	0	0	0	14	0	3430	0	0	300	2239	2239	3730	412	0	0	0	0	634	0	57	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	145135534866432	6	0	0	775	9	2	0	Sky[HotA]	1	5.61.168.133	053da885.dynamic.tele-ag.de	DE	europe.battle.net		0	0	Szatmarnemeti	0	0	0	0	1757	0.00	1257	39.00	1	1	0	0	0	4571	4571	1485.1787	0.00	0.00	0	0	0	0	5	4503	22290	950	0	56	279924	424175	803266	0	4	288819	0	0	333925	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	268280837177344	25	0	0	1235	9	2	0	Kipopstok	8	145.90.82.175	175pc82.sshunet.nl	NL	europe.battle.net		0	0	Antibean	0	0	0	0	4926	0.00	2073	43.00	2	2	0	0	0	2308	2308	1494.4407	0.00	0.00	0	0	0	0	14	0	17	3587	0	7449	11334	9730	10091	1493	0	801	0	0	2067	0	16	0	0	0	3590	2402	0	0	0	0	0	0	0	0	0	0	0	222589352019040	10	0	0	2063	9	2	0	Rokin	2	91.192.89.241	nat-i411.etth.elomza.pl	PL	server.eurobattle.net		0	0	Kolosvar	0	0	0	0	0	0.00	3151	0.00	0	0	0	0	0	0	0	1500.0000	0.00	0.00	0	0	0	0	0	0	0	0	0	1190	1373	1373	856	0	0	0	0	0	677	133	115	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	4398046511104	4	0	0	713	9	2	0	Dudlan66	9	14.231.14.145	static.vnpt.vn	VN	useast.battle.net		0	1	Seleucus Romanus	0	0	1	0	171580	0.00	4026	88.00	64	25	39	13	24	23	2199	1582.4933	0.00	0.00	7	152	214	3	155	0	14342	1920	18155	10246	13327	10299	44490	461	22488	1021	0	0	3063	8616	0	0	0	0	1780	1675	0	0	0	0	0	0	0	0	0	0	0	264160944289792	25	25	0	0	100	1	'),
(255, 0, 2, '2018-03-14 17:56:03', 'Werewolf Transylvania #332', '2018-03-14 19:48:08', '2018-03-14 20:09:53', '2018-03-14 20:10:13', 2700500, 1, 6, 6, 2, 0, 0, 0, 0, 0, 6, 0, 3, 2, 0, 0, '1	Tertlu	3	212.53.104.117	m212-53-104-117.cust.tele2.ee	EE	europe.battle.net		0	0	Tertlu	0	0	0	0	5612	0.00	0	56	2	2	0	0	0	2085	2085	1496.7168	0.00	0.00	0	0	0	0	14	0	18530	1365	0	2558	12219	10213	20900	1894	4552	0	0	0	24	2486	0	0	0	0	1800	0	0	0	0	0	0	0	0	0	0	0	0	270862381090688	16	17	0	0	100	1	1	Holten	8	87.50.30.34	x1-6-14-91-82-32-bc-80.cpe.webspeed.dk	DK	europe.battle.net		0	0	Holten	0	0	0	0	9556	0.00	0	72	2	2	0	0	0	1331	1331	1497.3623	0.00	0.00	0	0	0	0	12	1171	38991	3335	0	13180	11930	0	12825	0	3027	160	0	0	0	205	572	0	3951	86	55729471	29150797	49727750	0	0	0	5766	0	0	0	0	0	0	277597124781824	10	0	0	0	100	0	1	777Butcher777	9	192.164.252.128	192-164-252-128.adsl.highway.telekom.at	AT	europe.battle.net		0	0	777Butcher777	0	0	0	0	11976	0.00	0	64	5	4	1	1	0	1084	1084	1500.0000	0.00	0.00	0	0	4	0	21	16	24235	3315	0	15050	11534	0	14321	0	951	43	0	0	0	95	0	0	2253	45	21434380	8573773	58301500	0	0	0	2298	0	0	0	0	0	0	281474972746848	12	0	0	0	100	0	0	Moinmoin1116	10	93.235.180.17	p5DEBB411.dip0.t-ipconnect.de	DE	europe.battle.net		0	0	Moinmoin1116	0	0	0	0	0	0.00	128	0.00	0	0	0	0	0	0	0	1500.0000	0.00	0.00	0	0	0	0	0	0	0	0	0	150	350	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	100	0	0	BeW_Golf-3	1	77.180.154.151	x4db49a97.dyn.telefonica.de	DE	useast.battle.net		0	0	BeW_Golf-3	0	0	0	0	95304	0.00	425	95.00	36	27	9	8	3	297	25	1454.7785	0.00	0.00	0	26	43	0	97	0	0	0	0	1137	715	340	599	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	4	5	0	0	100	1	0	IfDaddySaySo	2	109.108.3.242	109-108-3-242.bb.dnainternet.fi	FI	europe.battle.net		0	0	IfDaddySaySo	0	0	0	0	0	0.00	718	0.00	0	0	0	0	0	0	0	1500.0000	0.00	0.00	0	0	0	0	0	1800	2300	110	0	472	1972	1293	2935	0	0	0	0	0	0	0	20	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	182518930210816	5	0	0	713	3	2	0	Qutte	0	85.191.189.8	85.191.189.8	NL	europe.battle.net		0	0	Qutte	13	0	0	0	21421	0.00	1533	81.00	6	6	0	2	0	632	632	1496.6081	0.00	0.00	1	0	0	0	40	0	34835	80	0	3086	6918	6918	37856	3964	0	0	0	0	805	0	0	0	0	0	4560	0	0	0	0	0	0	0	0	0	0	0	0	268280870763520	12	6	0	1528	3	2	0	Rhoarke	6	68.47.53.162	c-68-47-53-162.hsd1.wi.comcast.net	US	useast.battle.net		0	0	Rhoarke	4	0	0	0	6212	0.00	1574	92.00	3	3	0	1	0	1914	1914	1496.8000	0.00	0.00	0	0	0	0	17	3250	0	0	1941	756	3802	3727	5649	0	0	574	0	0	476	0	25	0	0	25	600	640	25	0	0	0	0	0	0	0	0	0	0	175921860444160	10	0	0	0	100	0	'),
(256, 0, 0, '2018-03-14 17:56:01', 'Werewolf Transylvania #349', '2018-03-14 20:10:01', '1970-01-01 03:00:00', '1970-01-01 03:00:00', 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 16, 0, 4, 0, 0, 0, '1	ronnocpost	0	76.184.171.231	cpe-76-184-171-231.tx.res.rr.com	US	useast.battle.net		0	0	ronnocpost	0	0	0	0	26910	0.00	0	82	11	10	1	1	1	487	487	1482.9279	0.00	0.00	0	2	2	0	64	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	100	0	1	Shokumoku	9	76.97.53.38	c-76-97-53-38.hsd1.ga.comcast.net	US	useast.battle.net		0	0	Shokumoku	0	0	0	0	160037	0.00	0	82	65	55	10	10	1	398	398	1333.1818	0.00	0.00	0	20	53	1	340	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	100	0	1	CagriCiv	8	72.141.104.224	CPE64777db33193-CM64777db33190.cpe.net.fido.ca	CA	europe.battle.net		0	0	CagriCiv	0	0	0	0	53320	0.00	0	49	24	22	2	5	0	514	20	1491.3018	0.00	0.00	0	1	5	0	67	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	100	0	1	Kvass	1	212.117.9.124	client-212-117-9-124.cgates.lt	LT	europe.battle.net		0	0	Kvass	0	0	0	0	265707	0.00	0	96	107	77	25	38	5	217	172	1474.6578	0.00	0.00	3	12	39	0	86	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	100	0	');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chatlog`
--
ALTER TABLE `chatlog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wwt_current_games`
--
ALTER TABLE `wwt_current_games`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chatlog`
--
ALTER TABLE `chatlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=536664;

--
-- AUTO_INCREMENT for table `wwt_current_games`
--
ALTER TABLE `wwt_current_games`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=257;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
